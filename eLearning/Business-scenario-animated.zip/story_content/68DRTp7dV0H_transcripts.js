
(function() {
    const data = {"transcripts":[{"name":"captions","cues":[{"start":64,"text":"After a couple of months of meetings and collaborations,"},{"start":2800,"text":"ExampleCompany has aligned their stakeholders"},{"start":5169,"text":"and identified gaps across "},{"start":6705,"text":"all Cloud Adoption Framework perspectives."},{"start":9280,"text":"They meet with you and Carrie again to discuss the next step."}]}]};
    window.globalLoadJsAsset('story_content/68DRTp7dV0H_transcripts.js', JSON.stringify(data));
})();