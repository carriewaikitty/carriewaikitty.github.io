
(function() {
    const data = {"transcripts":[{"name":"captions","cues":[{"start":64,"text":"-[ExampleCompany]- Thank you for meeting with us today. "},{"start":1745,"text":"We are very interested in migrating everything to the cloud,"},{"start":4273,"text":"but we don't know where to start. "},{"start":5824,"text":"Can you please share your insights with us,"},{"start":7705,"text":"and help us to begin our cloud-adoption journey?"}]}]};
    window.globalLoadJsAsset('story_content/5vhKQKjsXYv_transcripts.js', JSON.stringify(data));
})();