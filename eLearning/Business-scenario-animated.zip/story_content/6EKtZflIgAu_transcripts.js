
(function() {
    const data = {"transcripts":[{"name":"captions","cues":[{"start":128,"text":"Leaders at ExampleCompany have heard about "},{"start":1961,"text":"the benefits of using cloud computing"},{"start":4048,"text":"and they are beginning to wonder"},{"start":5320,"text":"if they should consider to move to the cloud."},{"start":7712,"text":"They scheduled a meeting with you and Carrie Wan,"},{"start":9953,"text":"an account manager in your firm,"},{"start":11584,"text":"to talk about their cloud-adoption journey."},{"start":14080,"text":"How can you help them use the Cloud Adoption Framework"},{"start":16352,"text":"to ensure a smooth transition?"}]}]};
    window.globalLoadJsAsset('story_content/6EKtZflIgAu_transcripts.js', JSON.stringify(data));
})();