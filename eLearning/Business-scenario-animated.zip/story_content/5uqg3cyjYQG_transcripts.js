
(function() {
    const data = {"transcripts":[{"name":"captions","cues":[{"start":96,"text":"Thank you for meeting with us again today. "},{"start":1920,"text":"We have answered questions and concerns from our stakeholders,"},{"start":4785,"text":"and everyone supports the decision"},{"start":6264,"text":"to migrate to the cloud."},{"start":8168,"text":"We drafted our migration strategy."},{"start":10456,"text":"We are very excited about this"},{"start":11702,"text":"and want to migrate everything to cloud at once."},{"start":14544,"text":"Do you think this is a good idea?"}]}]};
    window.globalLoadJsAsset('story_content/5uqg3cyjYQG_transcripts.js', JSON.stringify(data));
})();